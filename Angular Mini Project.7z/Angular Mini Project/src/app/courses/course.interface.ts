export interface Course {
    name: string
    duration: string
    time:string
}