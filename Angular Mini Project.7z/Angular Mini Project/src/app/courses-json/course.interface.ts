export interface Course {
    id: number
    name: string
    price: number
}